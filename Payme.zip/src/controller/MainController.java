package controller;

import dto.LoginRecord;
import dto.RegisterRecord;
import service.MainService;
import util.Util;

public class MainController {
    MainService mainService = new MainService();

    public void start() {

        while (true) {
            System.out.println("""
                1. Login
                2. Registration
                0. Exit
                """);
            int option = Util.getNumber("Choose an option");

            switch (option) {
                case 1 -> {
                    myLogin();
                }
                case 2 -> {
                    myRegistration();
                }
                case 0 -> {
                    System.out.println("Good bye!");
                    System.exit(0);
                }
            }
        }
    }

    private void myRegistration() {
        String userName = Util.getText("Enter your name");
        String password = Util.getText("Enter your password");
        String phoneNumber = Util.getText("Enter your phone number");

        RegisterRecord registerRecord = new RegisterRecord(userName, password, phoneNumber);

        if (!mainService.registerUser(registerRecord)) {
            System.out.println("User has already exists!");
        }else {
            System.out.println("User added successfully!");

            MainMenu();
        }
    }

    private void myLogin() {

        String phoneNumber = Util.getText("Enter your phone number");
        String password = Util.getText("Enter your password");

        LoginRecord loginRecord = new LoginRecord(phoneNumber, password);

        if (mainService.loginUser(loginRecord)) {
            System.out.println("Welcome " + mainService.getCurrentUser().getUserName() + "!");

            MainMenu();
        }

    }

    private void MainMenu() {
        while (true) {
            System.out.println("""
                1.
                2.
                3.
                4.
                0. Log out
                """);

            int option = Util.getNumber("Choose an option");

            switch (option) {
                case 1 -> {}
                case 2 -> {}
                case 3 -> {}
                case 4 -> {}
                case 0 -> {
                    System.out.println("I am looking forward to seeing to you!");
                    return;
                }
            }

        }
    }

}
