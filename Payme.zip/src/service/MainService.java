package service;

import dto.LoginRecord;
import dto.RegisterRecord;

import entity.User;

import java.util.ArrayList;

public class MainService {
    ArrayList<User> userList = new ArrayList<>();
    public User currentUser;

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    public boolean registerUser(RegisterRecord userRecord) {
        for (User user : userList) {
            if (user.getPhoneNumber().equals(userRecord.phoneNumber())) {
                return false;
            }
        }

        User user = new User(userRecord.userName(), userRecord.password(), userRecord.phoneNumber());

        userList.add(user);

        return true;
    }

    public boolean loginUser(LoginRecord loginRecord) {
        for (User user : userList) {
            if (user.getPhoneNumber().equals(loginRecord.phoneNumber())
            || user.getPassword().equals(loginRecord.password())
            ) {
                setCurrentUser(user);
                return true;
            }
        }

        return false;
    }

}

