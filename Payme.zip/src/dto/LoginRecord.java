package dto;

public record LoginRecord(String phoneNumber, String password) {
    public LoginRecord {
        if (password.length() < 8) {
            throw new RuntimeException("Username is less than 8");
        }

        if (phoneNumber.length() < 9 ) {
            throw new RuntimeException("Phone number is less than 9");
        }
    }
}
