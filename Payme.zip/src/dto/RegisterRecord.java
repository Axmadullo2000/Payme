package dto;

public record RegisterRecord(String userName, String password, String phoneNumber) {

    public RegisterRecord {
        if (userName.length() < 5) {
            throw new RuntimeException("Username is less than 5");
        }

        if (password.length() < 8) {
            throw new RuntimeException("Username is less than 8");
        }

        if (phoneNumber.length() < 9 ) {
            throw new RuntimeException("Phone number is less than 9");
        }


    }

}
