package util;

import java.util.Scanner;

public class Util {
    public static Scanner intScanner = new Scanner(System.in);
    public static Scanner strScanner = new Scanner(System.in);

    public static int getNumber(String text) {
        System.out.print(text + ": ");
        return intScanner.nextInt();
    }

    public static String getText(String text) {
        System.out.print(text + ": ");
        return strScanner.nextLine();
    }



}
